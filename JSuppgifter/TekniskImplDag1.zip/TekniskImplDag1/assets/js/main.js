const prizearray = new Array();

prizearray[0] = new Image();
prizearray[0].src = "assets/images/grapes.png"
prizearray[0].title = "grape";
prizearray[0].audio = new Audio();
prizearray[0].audio.src = 'assets/audio/bass.mp3';
prizearray[0].onload = function() {
                          this.audio.play();
                        }

prizearray[1] = new Image();
prizearray[1].src = "assets/images/melon.png"
prizearray[1].title = "melon";
prizearray[1].audio = new Audio();
prizearray[1].audio.src = 'assets/audio/bass.mp3';
prizearray[1].onload = function() {
                          this.audio.play();
                        }

prizearray[2] = new Image();
prizearray[2].src = "assets/images/watermelon.png"
prizearray[2].title = "watermelon";
prizearray[2].audio = new Audio();
prizearray[2].audio.src = 'assets/audio/bass.mp3';
prizearray[2].onload = function() {
                          this.audio.play();
                        }

prizearray[3] = new Image();
prizearray[3].src = "assets/images/tangerine.png"
prizearray[3].title = "tangerine";
prizearray[3].audio = new Audio();
prizearray[3].audio.src = 'assets/audio/bass.mp3';
prizearray[3].onload = function() {
                          this.audio.play();
                        }

prizearray[4] = new Image();
prizearray[4].src = "assets/images/lemon.png"
prizearray[4].title = "lemon";
prizearray[4].audio = new Audio();
prizearray[4].audio.src = 'assets/audio/bass.mp3';
prizearray[4].onload = function() {
                          this.audio.play();
                        }

prizearray[5] = new Image();
prizearray[5].src = "assets/images/banana.png"
prizearray[5].title = "banana";
prizearray[5].audio = new Audio();
prizearray[5].audio.src = 'assets/audio/bass.mp3';
prizearray[5].onload = function() {
                          this.audio.play();
                        }

prizearray[6] = new Image();
prizearray[6].src = "assets/images/pineapple.png"
prizearray[6].title = "pineapple";
prizearray[6].audio = new Audio();
prizearray[6].audio.src = 'assets/audio/bass.mp3';
prizearray[6].onload = function() {
                          this.audio.play();
                        }

prizearray[7] = new Image();
prizearray[7].src = "assets/images/hot_pepper.png"
prizearray[7].title = "hot pepper";
prizearray[7].audio = new Audio();
prizearray[7].audio.src = 'assets/audio/bass.mp3';
prizearray[7].onload = function() {
                          this.audio.play();
                        }

prizearray[8] = new Image();
prizearray[8].src = "assets/images/apple.png"
prizearray[8].title = "apple";
prizearray[8].audio = new Audio();
prizearray[8].audio.src = 'assets/audio/bass.mp3';
prizearray[8].onload = function() {
                          this.audio.play();
                        }

prizearray[9] = new Image();
prizearray[9].src = "assets/images/green_apple.png"
prizearray[9].title = "gapple";
prizearray[9].audio = new Audio();
prizearray[9].audio.src = 'assets/audio/bass.mp3';
prizearray[9].onload = function() {
                          this.audio.play();
                        }

prizearray[10] = new Image();
prizearray[10].src = "assets/images/pear.png"
prizearray[10].title = "pear";
prizearray[10].audio = new Audio();
prizearray[10].audio.src = 'assets/audio/bass.mp3';
prizearray[10].onload = function() {
                          this.audio.play();
                        }

prizearray[11] = new Image();
prizearray[11].src = "assets/images/peach.png"
prizearray[11].title = "peach";
prizearray[11].audio = new Audio();
prizearray[11].audio.src = 'assets/audio/bass.mp3';
prizearray[11].onload = function() {
                          this.audio.play();
                        }

prizearray[12] = new Image();
prizearray[12].src = "assets/images/crown.png"
prizearray[12].title = "crown";
prizearray[12].audio = new Audio();
prizearray[12].audio.src = 'assets/audio/bass.mp3';
prizearray[12].onload = function() {
                          this.audio.play();
                        }

function spin() {
  // Didn't get anything done in javascript, i want to die in real life
}
